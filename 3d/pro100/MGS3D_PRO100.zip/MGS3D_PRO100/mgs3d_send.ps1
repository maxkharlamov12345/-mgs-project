﻿# MGS 3D — окно отправки модели из PRO100 в CRM MGS (Макс 12.11: менеджер выбирает КЛИЕНТА из CRM, а не проект).
# 3D-проект = изделие: у клиента выбирается его изделие (загрузка его заменяет) или «+ Новое изделие»; «+ Новый клиент» заводит карточку в «Взят в работу».
# Запускается плагином mgs3d.plg после экспорта в OBJ: -Dir <папка экспорта> -Title <заголовок окна PRO100>
param([string]$Dir, [string]$Title = '', [string]$Conf = '', [int]$Build = 0)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Windows.Forms, System.Drawing, System.Net.Http
[System.Windows.Forms.Application]::EnableVisualStyles()

$Here    = Split-Path -Parent $PSCommandPath
$Data    = Join-Path $env:LOCALAPPDATA 'MGS3D'
$LogFile = Join-Path $Data 'logs\send.log'
New-Item -ItemType Directory -Force -Path (Join-Path $Data 'logs') | Out-Null
function Log($m) { Add-Content -Path $LogFile -Value ("{0:HH:mm:ss}  {1}" -f (Get-Date), $m) -Encoding UTF8 }
Log "=== запуск: $Dir | $Title"

# ---------- настройки ----------
function Read-Ini($path) {
  $r = @{}; $sec = ''
  if (Test-Path $path) {
    foreach ($l in Get-Content $path -Encoding UTF8) {
      $l = $l.Trim()
      if ($l -match '^\[(.+)\]$') { $sec = $Matches[1]; continue }
      if ($l -match '^([^;=]+)=(.*)$') { $r["$sec.$($Matches[1].Trim())"] = $Matches[2].Trim() }
    }
  }
  $r
}
$CfgDir = if ($Conf -and (Test-Path $Conf)) { $Conf } else { $Here }   # настройки — в папке установки (PRO100\plugins), даже если окно запущено из обновления
$Ini  = Read-Ini (Join-Path $CfgDir 'mgs3d.ini')
$Url  = if ($Ini['service.url']) { $Ini['service.url'].TrimEnd('/') } else { 'https://api.mgsmebel.com' }
$Key  = if ($Ini['service.key']) { $Ini['service.key'] } else { 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzkzMzc1NDI2LCJleHAiOjIxMDg3MzU0MjZ9.exy6cZNIkPj-oxZPuafx1BiBEQO4Hsav4bCQ2Z3mbDs' }
$Site = if ($Ini['service.site']) { $Ini['service.site'].TrimEnd('/') } else { 'https://my.mgsmebel.com' }
# CRM: рабочая — app.mgsmebel.com/crm.html, тестовая — test.mgsmebel.com/3d/crm.html (если обновления берутся с теста)
$App  = if ($Ini['service.app']) { $Ini['service.app'].TrimEnd('/') } elseif ("$($Ini['update.url'])" -like '*test.mgsmebel.com*') { 'https://test.mgsmebel.com/3d' } else { 'https://app.mgsmebel.com' }
# откуда клиент о нас узнал (Макс 12.11; тот же список — в crm.html SOURCES)
$Sources = @('Проходящий трафик','Заявка','Рекомендация')

# ---------- автообновление: свежие плагин и окно отправки с сервера (без прав администратора) ----------
# manifest.json: { version: N, files: [ {name, sha256, size} ] }. Скачиваем в %LOCALAPPDATA%\MGS3D\bin, проверяем sha256.
# Окно отправки — со следующего нажатия, плагин (mgs3d_core.dll.new) — со следующего запуска PRO100. Выключить: [update] enabled=0.
function Update-Self {
  try {
    if ($Ini['update.enabled'] -eq '0') { return }
    $base = if ($Ini['update.url']) { $Ini['update.url'].TrimEnd('/') } else { 'https://app.mgsmebel.com/pro100/update' }
    $bin = Join-Path $Data 'bin'; New-Item -ItemType Directory -Force -Path $bin | Out-Null
    $verFile = Join-Path $bin 'version.txt'
    $cur = 0; if (Test-Path $verFile) { [int]::TryParse((Get-Content $verFile -Raw).Trim(), [ref]$cur) | Out-Null }
    $have = [Math]::Max($cur, $Build)
    $hc = New-Object Net.Http.HttpClient; $hc.Timeout = [TimeSpan]::FromSeconds(8)
    $m = $hc.GetStringAsync("$base/manifest.json?t=" + [DateTime]::UtcNow.Ticks).GetAwaiter().GetResult() | ConvertFrom-Json
    if ([int]$m.version -le $have) { Log "обновлений нет (у нас $have, на сервере $($m.version))"; return }
    $hc.Timeout = [TimeSpan]::FromSeconds(60)
    foreach ($f in $m.files) {
      if ($f.name -notmatch '^[\w.\-]+$') { throw "плохое имя файла: $($f.name)" }
      $tmp = Join-Path $bin ($f.name + '.dl')
      [IO.File]::WriteAllBytes($tmp, $hc.GetByteArrayAsync("$base/$($f.name)?v=$($m.version)").GetAwaiter().GetResult())
      $h = (Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower()
      if ($h -ne ([string]$f.sha256).ToLower()) { Remove-Item $tmp -Force; throw "не сошлась контрольная сумма $($f.name)" }
    }
    foreach ($f in $m.files) {
      $tmp = Join-Path $bin ($f.name + '.dl')
      $dst = if ($f.name -like '*.dll') { Join-Path $bin ($f.name + '.new') } else { Join-Path $bin $f.name }
      Move-Item $tmp $dst -Force
    }
    Set-Content -Path $verFile -Value $m.version -Encoding ASCII
    Log "обновление $have → $($m.version) скачано (окно перезапускается новым, плагин — после перезапуска PRO100)"
    # Макс 12.11: «PRO100 сама не обновилась — после отправки всё тот же функционал»: раньше новое окно включалось только со
    # СЛЕДУЮЩЕЙ отправки. Теперь сразу перезапускаемся из bin новым окном с теми же параметрами (без SW_HIDE — см. CLAUDE.md).
    $new = Join-Path $bin 'mgs3d_send.ps1'
    if (Test-Path $new) {
      $q = { param($v) '"' + ([string]$v -replace '"', "'") + '"' }
      $si = New-Object Diagnostics.ProcessStartInfo 'powershell.exe'
      $si.Arguments = "-NoProfile -ExecutionPolicy Bypass -STA -File $(& $q $new) -Dir $(& $q $Dir) -Title $(& $q $Title) -Conf $(& $q $CfgDir) -Build $([int]$m.version)"
      $si.UseShellExecute = $false; $si.CreateNoWindow = $true; $si.WorkingDirectory = $CfgDir
      [void][Diagnostics.Process]::Start($si)
      Log "перезапуск новым окном $($m.version)"
      exit
    }
  } catch { Log "проверка обновлений не удалась: $($_.Exception.Message)" }
}
Update-Self

# ---------- сеть ----------
$script:Token = $null
function Body($o) { $j = $o | ConvertTo-Json -Depth 6 -Compress; return ,([byte[]][Text.Encoding]::UTF8.GetBytes($j)) }
function Api($method, $path, $body = $null, $extra = @{}) {
  $h = @{ apikey = $Key }
  if ($script:Token) { $h.Authorization = "Bearer $script:Token" }
  foreach ($k in $extra.Keys) { $h[$k] = $extra[$k] }
  $p = @{ Method = $method; Uri = "$Url$path"; Headers = $h; UseBasicParsing = $true }
  if ($null -ne $body) { $p.Body = [byte[]](Body $body); $p.ContentType = 'application/json; charset=utf-8' }
  $resp = Invoke-WebRequest @p
  $txt = [Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray())
  if (!$txt) { return $null }
  $o = ConvertFrom-Json $txt
  if ($o -is [array]) { foreach ($i in $o) { $i } } else { $o }   # по одному элементу: вызывающий собирает через @()
}
# ждать задачу .NET, не замораживая окно
function Wait-Task($t) { while (-not $t.IsCompleted) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 40 }; if ($t.IsFaulted) { throw $t.Exception.InnerException } }
# сжатие текстовых файлов модели (OBJ ужимается в 5–8 раз; лимит Supabase — 50 МБ на файл)
function Gzip-File($src, $dst) {
  $in = [IO.File]::OpenRead($src); $out = [IO.File]::Create($dst)
  $gz = New-Object IO.Compression.GZipStream($out, [IO.Compression.CompressionLevel]::Optimal)
  try { Wait-Task ($in.CopyToAsync($gz, 1048576)) } finally { $gz.Dispose(); $out.Dispose(); $in.Dispose() }
}
$script:Http = New-Object Net.Http.HttpClient; $script:Http.Timeout = [TimeSpan]::FromMinutes(30)
function Upload-File($file, $path, $ct) {
  $fs = [IO.File]::OpenRead($file)
  try {
    $req = New-Object Net.Http.HttpRequestMessage([Net.Http.HttpMethod]::Post, "$Url/storage/v1/object/models/$path")
    [void]$req.Headers.TryAddWithoutValidation('apikey', $Key)
    [void]$req.Headers.TryAddWithoutValidation('Authorization', "Bearer $script:Token")
    [void]$req.Headers.TryAddWithoutValidation('x-upsert', 'true')
    $req.Content = New-Object Net.Http.StreamContent($fs)
    $req.Content.Headers.ContentType = [Net.Http.Headers.MediaTypeHeaderValue]::Parse($ct)
    $t = $script:Http.SendAsync($req); Wait-Task $t
    $r = $t.Result
    if (-not $r.IsSuccessStatusCode) {
      $b = $r.Content.ReadAsStringAsync().Result
      if ($b -match 'maximum allowed size|too large|413') { throw "Сервер: файл $([IO.Path]::GetFileName($file)) слишком большой ($([math]::Round((Get-Item $file).Length/1MB,1)) МБ, предел 50 МБ)." }
      throw "Сервер ответил ошибкой $([int]$r.StatusCode) при загрузке. $b"
    }
  } finally { $fs.Dispose() }
}

function Why($e) {
  if ($e.Exception.Message -like 'Сервер*') { return $e.Exception.Message }
  $ex = $e.Exception; while ($ex.InnerException -and -not $ex.Response) { $ex = $ex.InnerException }
  $r = $null; try { $r = $e.Exception.Response } catch {}
  if (-not $r) {
    return "Нет связи с сервером MGS 3D (api.mgsmebel.com).`n$($e.Exception.Message)`nПроверьте интернет и попробуйте ещё раз."
  }
  $code = [int]$r.StatusCode; $body = Resp-Body $e
  if ($code -eq 400 -and $body -match 'invalid_credentials|Invalid login') { return 'Неверная почта или пароль. Введите те же, что на сайте кабинета (app.mgsmebel.com). Проверьте раскладку клавиатуры.' }
  if ($body -match 'email_not_confirmed') { return 'Почта не подтверждена. В Supabase у пользователя должна стоять галочка Auto Confirm.' }
  if ($body -match 'user_banned') { return 'Сотрудник отключён. Включите его в «Управление → Сотрудники».' }
  "Сервер ответил ошибкой $code.`n" + ($body.Substring(0, [math]::Min(300, $body.Length)))
}
# PowerShell 5.1 сам вычитывает тело ответа с ошибкой в ErrorDetails — поток после этого пустой (12.11: окно писало голое «400»)
function Resp-Body($e) {
  $b = ''
  try { if ($e.ErrorDetails -and $e.ErrorDetails.Message) { $b = [string]$e.ErrorDetails.Message } } catch {}
  if (!$b) { try { $r = $e.Exception.Response; if ($r) { $s = New-Object IO.StreamReader($r.GetResponseStream()); $b = $s.ReadToEnd() } } catch {} }
  $b
}
function ErrText($e) {
  $t = $e.Exception.Message
  $b = Resp-Body $e
  if ($b) { $t = "$t`n$b" }
  $t
}

# ---------- вход (ключ хранится зашифрованным средствами Windows) ----------
$SessFile = Join-Path $Data 'session.dat'
function Save-Session($rt) { ConvertTo-SecureString $rt -AsPlainText -Force | ConvertFrom-SecureString | Set-Content $SessFile }
function Load-Session {
  if (!(Test-Path $SessFile)) { return $null }
  try {
    $ss = Get-Content $SessFile | ConvertTo-SecureString
    [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss))
  } catch { $null }
}
function Use-Auth($a) { $script:Token = $a.access_token; $script:Email = $a.user.email; Save-Session $a.refresh_token }
function Try-Refresh {
  $rt = Load-Session; if (!$rt) { return $false }
  try { $script:Token = $null; Use-Auth (Api 'POST' '/auth/v1/token?grant_type=refresh_token' @{ refresh_token = $rt }); return $true }
  catch { Log ("refresh: " + (ErrText $_)); return $false }
}

# ---------- что отправляем ----------
$Exts = '\.(obj|mtl|png|jpe?g|bmp|gif|webp|tga|json)$'
$Files = @(Get-ChildItem -Path $Dir -Recurse -File | Where-Object { $_.Name -match $Exts })
$seen = @{}; $Files = @($Files | Where-Object { $k = $_.Name.ToLower(); if ($seen[$k]) { $false } else { $seen[$k] = 1; $true } })
$ObjFile = $Files | Where-Object { $_.Extension -ieq '.obj' } | Select-Object -First 1
$TotalMB = [math]::Round((($Files | Measure-Object Length -Sum).Sum) / 1MB, 1)

function Guess-Title($t) {
  if ($t -match '([^\\/:*?"<>|]+)\.(sto|pro|p100|prj|s3d)\b') { return $Matches[1].Trim() }
  $t = $t -replace 'PRO100\s*[\d\.]*', '' -replace '^[\s\-–—|:]+|[\s\-–—|:]+$', ''
  $t
}
# ---------- окно ----------
$Lime = [Drawing.Color]::FromArgb(191,214,48); $Ink = [Drawing.Color]::FromArgb(20,26,3)
$Bg = [Drawing.Color]::FromArgb(15,14,12); $Card = [Drawing.Color]::FromArgb(29,32,34); $Fg = [Drawing.Color]::FromArgb(244,241,236); $Muted = [Drawing.Color]::FromArgb(141,147,140)
$F  = New-Object Drawing.Font('Segoe UI', 10)
$FB = New-Object Drawing.Font('Segoe UI Semibold', 10)
$FH = New-Object Drawing.Font('Segoe UI Semibold', 15)

$form = New-Object Windows.Forms.Form
$form.Text = 'MGS 3D — отправка модели'; $form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false; $form.MinimizeBox = $false; $form.ClientSize = New-Object Drawing.Size(460, 560)
$form.BackColor = $Bg; $form.ForeColor = $Fg; $form.Font = $F; $form.TopMost = $true
$ico = Join-Path $Here 'mgs3d.ico'; if (Test-Path $ico) { $form.Icon = New-Object Drawing.Icon($ico) }

function L($text, $x, $y, $w = 420, $font = $null, $color = $null) {
  $l = New-Object Windows.Forms.Label; $l.Text = $text; $l.Location = New-Object Drawing.Point($x, $y)
  $l.Size = New-Object Drawing.Size($w, 22); $l.AutoSize = $false
  if ($font) { $l.Font = $font }; if ($color) { $l.ForeColor = $color }; $l
}
function T($x, $y, $w = 420) { $t = New-Object Windows.Forms.TextBox; $t.Location = New-Object Drawing.Point($x, $y); $t.Width = $w; $t.BackColor = $Card; $t.ForeColor = $Fg; $t.BorderStyle = 'FixedSingle'; $t }
function C($x, $y, $w = 420) { $c = New-Object Windows.Forms.ComboBox; $c.DropDownStyle = 'DropDownList'; $c.Location = New-Object Drawing.Point($x, $y); $c.Width = $w; $c.BackColor = $Card; $c.ForeColor = $Fg; $c.FlatStyle = 'Flat'; $c }
function B($text, $x, $y, $w = 200, $primary = $true) {
  $b = New-Object Windows.Forms.Button; $b.Text = $text; $b.Location = New-Object Drawing.Point($x, $y); $b.Size = New-Object Drawing.Size($w, 38)
  $b.FlatStyle = 'Flat'; $b.Font = $FB; $b.Cursor = 'Hand'
  if ($primary) { $b.BackColor = $Lime; $b.ForeColor = $Ink; $b.FlatAppearance.BorderSize = 0 } else { $b.BackColor = $Bg; $b.ForeColor = $Fg; $b.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(60,64,68) }
  $b
}
function Panel { $p = New-Object Windows.Forms.Panel; $p.Dock = 'Fill'; $p.BackColor = $Bg; $p.Visible = $false; $form.Controls.Add($p); $p }

# --- вход ---
$pLogin = Panel
$pLogin.Controls.AddRange(@(
  (L 'MGS 3D' 20 18 420 $FH),
  (L 'Войдите один раз — дальше модели будут отправляться сразу.' 20 52 420 $null $Muted),
  (L 'Почта' 20 92 420 $null $Muted)))
$tEmail = T 20 116; $pLogin.Controls.Add($tEmail)
$pLogin.Controls.Add((L 'Пароль' 20 152 420 $null $Muted))
$tPass = T 20 176; $tPass.UseSystemPasswordChar = $true; $pLogin.Controls.Add($tPass)
$bLogin = B 'Войти' 20 222 420; $pLogin.Controls.Add($bLogin)
$lLoginMsg = L '' 20 272 420 $null $Muted; $lLoginMsg.Height = 150; $pLogin.Controls.Add($lLoginMsg)

# --- отправка ---
$pMain = Panel
$lHead = L 'Отправить модель' 20 16 420 $FH; $pMain.Controls.Add($lHead)
$lInfo = L '' 20 48 420 $null $Muted; $pMain.Controls.Add($lInfo)
$pMain.Controls.Add((L 'Клиент' 20 82 300 $null $Muted))
$lnkNew = New-Object Windows.Forms.LinkLabel; $lnkNew.Text = '+ Новый клиент'; $lnkNew.Location = New-Object Drawing.Point(320, 82); $lnkNew.Size = New-Object Drawing.Size(120, 22)
$lnkNew.TextAlign = 'TopRight'; $lnkNew.LinkColor = $Lime; $lnkNew.ActiveLinkColor = $Lime; $pMain.Controls.Add($lnkNew)
$cClient = C 20 106; $cClient.MaxDropDownItems = 16; $pMain.Controls.Add($cClient)
# новый клиент (Макс 12.11): имя и телефон обязательны, адреса нет, «откуда узнали» — список; список старых клиентов в этом режиме скрыт
$gNew = New-Object Windows.Forms.Panel; $gNew.Location = New-Object Drawing.Point(20, 106); $gNew.Size = New-Object Drawing.Size(420, 170); $gNew.Visible = $false; $pMain.Controls.Add($gNew)
$gNew.Controls.Add((L 'Имя клиента' 0 0 420 $null $Muted)); $tCN = T 0 22; $gNew.Controls.Add($tCN)
$gNew.Controls.Add((L 'Телефон клиента' 0 56 420 $null $Muted)); $tCP = T 0 78; $gNew.Controls.Add($tCP)
$gNew.Controls.Add((L 'Откуда о нас узнали' 0 112 420 $null $Muted)); $cSrc = C 0 134; $cSrc.Items.AddRange($Sources); $gNew.Controls.Add($cSrc)
# изделие = 3D-проект в CRM (его название — на плитке у превью); типа нет.
# Макс 12.11: у действующего клиента — выпадающий список ЕГО изделий: выбранное ЗАМЕНЯЕТСЯ этой загрузкой; «+ Новое изделие» — новое (название текстом).
$gItem = New-Object Windows.Forms.Panel; $gItem.Location = New-Object Drawing.Point(20, 146); $gItem.Size = New-Object Drawing.Size(420, 100); $pMain.Controls.Add($gItem)
$gItem.Controls.Add((L 'Изделие' 0 0 420 $null $Muted))
$cProj = C 0 22; $cProj.MaxDropDownItems = 16; $gItem.Controls.Add($cProj)
$tItem = T 0 22; $gItem.Controls.Add($tItem)
$lItemNote = L '' 0 54 420 $null $Muted; $gItem.Controls.Add($lItemNote)
$bSend = B 'Отправить' 20 246 420; $pMain.Controls.Add($bSend)
$bar = New-Object Windows.Forms.ProgressBar; $bar.Location = New-Object Drawing.Point(20, 266); $bar.Size = New-Object Drawing.Size(420, 8); $bar.Visible = $false; $pMain.Controls.Add($bar)
$lStatus = L '' 20 280 420 $null $Muted; $lStatus.Height = 100; $pMain.Controls.Add($lStatus)
$lWho = L '' 20 522 300 $null $Muted; $pMain.Controls.Add($lWho)
$lnkOut = New-Object Windows.Forms.LinkLabel; $lnkOut.Text = 'Выйти'; $lnkOut.Location = New-Object Drawing.Point(340, 522); $lnkOut.Size = New-Object Drawing.Size(100, 22); $lnkOut.TextAlign = 'TopRight'
$lnkOut.LinkColor = $Muted; $pMain.Controls.Add($lnkOut)

# --- готово ---
$pDone = Panel
$pDone.Controls.Add((L 'Готово' 20 18 420 $FH))
$lDone = L '' 20 54 420 $null $Muted; $lDone.Height = 44; $pDone.Controls.Add($lDone)
$pDone.Controls.Add((L 'Ссылка для клиента' 20 104 420 $null $Muted))
$tLink = T 20 128; $tLink.ReadOnly = $true; $pDone.Controls.Add($tLink)
$bOpen = B 'Открыть в 3D' 20 172 205; $pDone.Controls.Add($bOpen)
$bCopy = B 'Скопировать ссылку' 235 172 205 $false; $pDone.Controls.Add($bCopy)
$bCrm = B 'Открыть карточку в CRM' 20 222 420 $false; $pDone.Controls.Add($bCrm)
$bClose = B 'Закрыть' 20 272 420 $false; $pDone.Controls.Add($bClose)

function Show-Panel($p) { foreach ($x in @($pLogin, $pMain, $pDone)) { $x.Visible = ($x -eq $p) } }
function Busy($on, $text = '') { $form.UseWaitCursor = $on; $bSend.Enabled = -not $on; $bar.Visible = $on; $lStatus.ForeColor = $Muted; $lStatus.Text = $text; [Windows.Forms.Application]::DoEvents() }

$LastFile = Join-Path $Data 'last-client.txt'
$script:Clients = @()
# клиенты CRM, которых видит менеджер (кроме потерянных): свежие сверху
function Load-Clients {
  $script:Clients = @(Api 'GET' '/rest/v1/clients?select=id,num,name,phone,address,stage&stage=neq.lost&order=updated_at.desc')
  $cClient.Items.Clear()
  foreach ($c in $script:Clients) { $cClient.Items.Add((@("№$($c.num)", $c.name, $c.address) | Where-Object { $_ }) -join ' · ') | Out-Null }
  $last = if (Test-Path $LastFile) { (Get-Content $LastFile -Encoding UTF8 | Select-Object -First 1) } else { '' }
  $i = [array]::FindIndex([object[]]$script:Clients, [Predicate[object]]{ param($c) $c.id -eq $last })
  if ($cClient.Items.Count) { $cClient.SelectedIndex = [math]::Max(0, $i); Load-Projects }
  if (!$cClient.Items.Count) { Set-NewMode $true }
}
# изделия (3D-проекты) выбранного клиента: свежие сверху; название — у свежей выгрузки (старые проекты назывались именем клиента)
$script:Projects = @()
$NEW_ITEM = '+ Новое изделие'
function Proj-Title($p) { $it = @($p.items | Sort-Object { [string]$_.created_at } -Descending)[0]; if ($it -and $it.title) { [string]$it.title } else { [string]$p.title } }
function Load-Projects {
  $cProj.Items.Clear(); $script:Projects = @()
  if ($script:NewMode -or $cClient.SelectedIndex -lt 0) { Layout-Item; return }
  $cl = $script:Clients[$cClient.SelectedIndex]
  try { $script:Projects = @(Api 'GET' "/rest/v1/projects?select=id,title,share_token,created_at,items(id,title,created_at,files,glb)&client_id=eq.$($cl.id)&order=created_at.desc") }
  catch { Log ("projects: " + (ErrText $_)); $script:Projects = @() }
  foreach ($p in $script:Projects) {
    $it = @($p.items | Sort-Object { [string]$_.created_at } -Descending)[0]
    $when = if ($it) { ([datetime]$it.created_at).ToLocalTime().ToString('dd.MM HH:mm') } else { '' }
    $cProj.Items.Add((@((Proj-Title $p), $when) | Where-Object { $_ }) -join ' · ') | Out-Null
  }
  $cProj.Items.Add($NEW_ITEM) | Out-Null
  # подсказка: изделие с тем же названием, что в PRO100, — иначе «новое»
  $guess = (Guess-Title $Title).Trim().ToLower(); $pick = $script:Projects.Count
  for ($k = 0; $k -lt $script:Projects.Count; $k++) { if ((Proj-Title $script:Projects[$k]).Trim().ToLower() -eq $guess) { $pick = $k; break } }
  $cProj.SelectedIndex = $pick
  Layout-Item
}
function Replacing { (-not $script:NewMode) -and $cProj.SelectedIndex -ge 0 -and $cProj.SelectedIndex -lt $script:Projects.Count }
# что видно в блоке «Изделие»: список изделий (у действующего клиента) и/или поле названия (новое изделие)
function Layout-Item {
  $list = -not $script:NewMode; $cProj.Visible = $list
  $typing = -not (Replacing)
  $tItem.Visible = $typing; $tItem.Top = if ($list) { 58 } else { 22 }
  $lItemNote.Top = if ($list -and $typing) { 88 } else { 54 }
  $lItemNote.Text = if (Replacing) { 'Модель заменит это изделие у клиента (ссылка для клиента та же).' } else { '' }
  $h = 54 + $(if ($list -and $typing) { 36 } else { 0 }) + $(if ($lItemNote.Text) { 24 } else { 0 })
  $gItem.Height = $h + 4
  $y = $gItem.Top + $gItem.Height + 8; $bSend.Top = $y; $bar.Top = $y + 50; $lStatus.Top = $y + 64
}
$script:NewMode = $false
function Set-NewMode($on) {
  $script:NewMode = $on; $gNew.Visible = $on; $cClient.Visible = -not $on
  $lnkNew.Text = if ($on) { 'Выбрать из списка' } else { '+ Новый клиент' }
  $gItem.Top = if ($on) { 286 } else { 146 }
  if ($on) { $tItem.Text = Guess-Title $Title; Layout-Item; $tCN.Focus() | Out-Null } else { Load-Projects }
}
function Enter-Main {
  Show-Panel $pMain
  $lWho.Text = "Вы вошли: $script:Email"
  $lInfo.Text = "Файлов: $($Files.Count), $TotalMB МБ"
  $tItem.Text = Guess-Title $Title
  try { Busy $true 'Загружаем клиентов…'; Load-Clients; Busy $false }
  catch { Busy $false; $lStatus.ForeColor = [Drawing.Color]::Salmon; $lStatus.Text = 'Не удалось получить клиентов. ' + (Why $_); Log ("clients: " + (ErrText $_)) }
}

$lnkNew.Add_LinkClicked({ Set-NewMode (-not $script:NewMode) })
$cClient.Add_SelectionChangeCommitted({ Load-Projects })
$cProj.Add_SelectedIndexChanged({ if ($cProj.SelectedItem -eq $NEW_ITEM -and !$tItem.Text.Trim()) { $tItem.Text = Guess-Title $Title }; Layout-Item })
$lnkOut.Add_LinkClicked({ Remove-Item $SessFile -ErrorAction SilentlyContinue; $script:Token = $null; Show-Panel $pLogin })
$bLogin.Add_Click({
  $lLoginMsg.ForeColor = $Muted; $lLoginMsg.Text = 'Проверяем…'; $bLogin.Enabled = $false; [Windows.Forms.Application]::DoEvents()
  $ok = $false
  try { $script:Token = $null; Use-Auth (Api 'POST' '/auth/v1/token?grant_type=password' @{ email = $tEmail.Text.Trim(); password = $tPass.Text }); $tPass.Text = ''; $ok = $true }
  catch { $lLoginMsg.ForeColor = [Drawing.Color]::Salmon; $lLoginMsg.Text = (Why $_); Log ("login: " + (ErrText $_)) }
  if ($ok) { try { Enter-Main } catch { Log ("main: " + (ErrText $_)); [Windows.Forms.MessageBox]::Show("Ошибка окна: $($_.Exception.Message)", 'MGS 3D') | Out-Null } }
  $bLogin.Enabled = $true
})
$tPass.Add_KeyDown({ if ($_.KeyCode -eq 'Enter') { $bLogin.PerformClick() } })

$bSend.Add_Click({
  try {
    if (!$ObjFile) { throw 'В папке экспорта нет model.obj' }
    $old = $null
    if (Replacing) { $old = $script:Projects[$cProj.SelectedIndex]; $itemTitle = Proj-Title $old } else { $itemTitle = $tItem.Text.Trim() }
    $miss = @()
    if ($script:NewMode -and !$tCN.Text.Trim()) { $miss += 'имя клиента' }
    if ($script:NewMode -and !$tCP.Text.Trim()) { $miss += 'телефон клиента' }
    if (!$itemTitle) { $miss += 'изделие' }
    if ($miss.Count) { $lStatus.ForeColor = [Drawing.Color]::Salmon; $lStatus.Text = 'Заполните: ' + ($miss -join ', ') + '.'; return }
    Busy $true 'Готовим…'
    if ($script:NewMode) {
      $src = if ($cSrc.SelectedIndex -ge 0) { [string]$cSrc.SelectedItem } else { $null }
      $cl = @(Api 'POST' '/rest/v1/clients' @{ name = $tCN.Text.Trim(); phone = $tCP.Text.Trim(); want = $itemTitle; source = $src } @{ Prefer = 'return=representation' })[0]
    } else {
      if ($cClient.SelectedIndex -lt 0) { Busy $false; $lStatus.Text = 'Выберите клиента.'; return }
      $cl = $script:Clients[$cClient.SelectedIndex]
    }
    Set-Content $LastFile $cl.id -Encoding UTF8
    $script:ClientId = $cl.id
    if ($old) { $proj = $old }
    else { $proj = @(Api 'POST' '/rest/v1/projects' @{ title = $itemTitle; client = $cl.name; client_id = $cl.id } @{ Prefer = 'return=representation' })[0] }
    $itemId = [guid]::NewGuid().ToString()
    $list = New-Object Collections.ArrayList
    $bar.Maximum = $Files.Count; $bar.Value = 0
    $tmp = Join-Path $env:TEMP ("mgs3d-" + $itemId); New-Item -ItemType Directory -Force -Path $tmp | Out-Null
    try {
    for ($i = 0; $i -lt $Files.Count; $i++) {
      $f = $Files[$i]; $ext = $f.Extension.ToLower(); $src = $f.FullName; $gz = $false
      if ($ext -in '.obj', '.mtl' -and $f.Length -gt 256KB) {
        $lStatus.Text = "Сжимаем $($f.Name) ($([math]::Round($f.Length/1MB,1)) МБ)…"; [Windows.Forms.Application]::DoEvents()
        $src = Join-Path $tmp ("f$i$ext.gz"); Gzip-File $f.FullName $src; $gz = $true
      }
      $path = "$($proj.id)/$itemId/f$i$ext" + $(if ($gz) { '.gz' } else { '' })
      $ct = if ($gz) { 'application/gzip' } else { switch -regex ($ext) { '\.(obj|mtl)' { 'text/plain; charset=utf-8' } '\.png' { 'image/png' } '\.jpe?g' { 'image/jpeg' } '\.bmp' { 'image/bmp' } '\.gif' { 'image/gif' } '\.webp' { 'image/webp' } '\.json' { 'application/json' } default { 'application/octet-stream' } } }
      $mb = [math]::Round((Get-Item $src).Length / 1MB, 1)
      $lStatus.Text = "Отправляем $($i + 1) из $($Files.Count): $($f.Name) ($mb МБ)"; [Windows.Forms.Application]::DoEvents()
      Upload-File $src $path $ct
      $entry = @{ name = $f.Name; path = $path; size = (Get-Item $src).Length }; if ($gz) { $entry.gz = $true }
      [void]$list.Add($entry)
      $bar.Value = $i + 1
    }
    } finally { Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue }
    $lStatus.Text = 'Сохраняем изделие…'; [Windows.Forms.Application]::DoEvents()
    Api 'POST' '/rest/v1/items' @{ id = $itemId; project_id = $proj.id; title = $itemTitle; files = $list } | Out-Null
    # заменяем: прежние выгрузки этого изделия удаляем (запись и файлы) — только после того, как новая сохранилась
    if ($old -and @($old.items).Count) {
      $lStatus.Text = 'Убираем прежнюю модель…'; [Windows.Forms.Application]::DoEvents()
      try {
        $paths = @(); foreach ($it in @($old.items)) { foreach ($f in @($it.files)) { if ($f.path) { $paths += [string]$f.path } }; if ($it.glb -and $it.glb.path) { $paths += [string]$it.glb.path } }
        $ids = (@($old.items) | ForEach-Object { $_.id }) -join ','
        Api 'DELETE' "/rest/v1/items?id=in.($ids)" | Out-Null
        if ($paths.Count) { Api 'DELETE' '/storage/v1/object/models' @{ prefixes = $paths } | Out-Null }
        Log "заменено: $($old.id), удалено выгрузок $(@($old.items).Count), файлов $($paths.Count)"
      } catch { Log ("замена (старое не удалилось): " + (ErrText $_)) }
    }
    $link = "$Site/view.html?s=$($proj.share_token)&i=$itemId"
    Log "готово: $link"
    Busy $false
    $tLink.Text = $link
    $lDone.Text = if ($old) { "«$itemTitle» у клиента «$($cl.name)» (№$($cl.num)) заменено новой моделью." } else { "«$itemTitle» добавлено в карточку клиента «$($cl.name)» (№$($cl.num))." }
    Show-Panel $pDone
    Start-Process $link
    try { Remove-Item -Recurse -Force $Dir } catch {}
  } catch {
    $t = ErrText $_; Log "send: $t"
    Busy $false
    $lStatus.ForeColor = [Drawing.Color]::Salmon
    $lStatus.Text = if ($t -match '401|JWT|expired') { 'Вход устарел — нажмите «Выйти» и войдите снова.' } else { 'Не получилось отправить. ' + (Why $_) }
  }
})
$bOpen.Add_Click({ Start-Process $tLink.Text })
$bCrm.Add_Click({ Start-Process "$App/crm.html?c=$($script:ClientId)" })
$bCopy.Add_Click({ [Windows.Forms.Clipboard]::SetText($tLink.Text); $bCopy.Text = 'Скопировано' })
$bClose.Add_Click({ $form.Close() })

$form.Add_Shown({
  $form.Activate(); $form.TopMost = $false
  if (!$ObjFile) { [Windows.Forms.MessageBox]::Show('PRO100 не сохранил модель. Повторите «Отправить в MGS 3D…».', 'MGS 3D') | Out-Null; $form.Close(); return }
  if (Try-Refresh) { Enter-Main } else { Show-Panel $pLogin; $tEmail.Focus() | Out-Null }
})
$form.ShowInTaskbar = $true; $form.WindowState = 'Normal'
try { [void]$form.ShowDialog() } catch { Log ("form: " + (ErrText $_)); [Windows.Forms.MessageBox]::Show("Ошибка окна отправки:`n$($_.Exception.Message)", 'MGS 3D') | Out-Null }
